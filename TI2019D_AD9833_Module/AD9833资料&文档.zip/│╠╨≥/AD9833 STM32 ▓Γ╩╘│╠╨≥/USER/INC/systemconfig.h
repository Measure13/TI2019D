#ifndef __SYSTEMCONFIG_H
#define __SYSTEMCONFIG_H

void RCC_Configuration(void);

void GPIO_Configuration(void);

void NVIC_Configuration(void);

void SystemConfiguration(void);



#endif

